using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using example_db.Data;
using ModelExample.Models;


namespace controller_example.Controllers
{
    static class HelloWorldController{
        public static void AdicionarControllersExemplo(this WebApplication app){
            app.MapGet("/helloworld",HelloWorld);
            app.MapGet("/create/example",ExampleCreate);

        }

        public static string HelloWorld(){
            return "HelloWorld!";
        }

        public static Example ExampleCreate(){
            using (var dbContext = new MyProjectDbContext())
            {
                Example example = new Example("Renzo"); 
                dbContext.Examples.Add(example); 
                dbContext.SaveChanges(); 
                return example; 
            }
        }
        


    }
    


}

