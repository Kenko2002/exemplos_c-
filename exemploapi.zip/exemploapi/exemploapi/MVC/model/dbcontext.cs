using Microsoft.EntityFrameworkCore;
using ModelExample.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example_db.Data
{

    public class MyProjectDbContext: DbContext
    {
        public DbSet<Example> Examples { get; set; }

        private string localConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ScreenSoundApi;Integrated Security=True;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";


        public MyProjectDbContext(DbContextOptions<MyProjectDbContext> options) : base(options)
        {

        }
        public MyProjectDbContext()
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //if (optionsBuilder.IsConfigured)
                //return;
            optionsBuilder.UseSqlServer(localConnectionString);
            Console.WriteLine("SQL SERVER ATIVADO!");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Inserido por motivos de teste.
            //modelBuilder.Entity<Artista>().Navigation(a => a.Musicas).AutoInclude();
            //modelBuilder.Entity<Musica>().Navigation(m => m.Artista).AutoInclude();
        }
    }
}





