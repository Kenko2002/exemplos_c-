using System;

namespace ModelExample.Models
{
    public class Example
    {
        public int Id { get; set; }
        public string? Nome { get; set; } // Corrigido o nome da propriedade para maiúscula

        public Example(string nome)
        {
            this.Id = 0;
            this.Nome = nome;
        }
    }

    
}